﻿using System;
using System.Collections.Generic;

class User //This serves as a blueprint for creating user objects in the online system which can be used for managing user accounts
{
    public string Username { get; set; } //Get and Set is a way to achieve encapsulation by controlling access to the class's attributes.
    public string Password { get; set; }
    public string SecurityQuestion { get; set; }
    public string SecurityAnswer { get; set; }
    public string Name { get; set; }
    public string Surname { get; set; }
    public decimal Balance { get; set; } = 1000.00m; //The opening balance of R1000.00 is requested hence we use 1000.
}

class Program //This serves as a blueprint for creating user objects in the online system which can be used for managing user accounts
{
    private static Dictionary<string, User> users = new Dictionary<string, User>(); //Allows you to associate keys with values, providing efficient look-up and retrieval based on the keys.
    private static User currentUser;
    private const int MaxLoginAttempts = 3;

    static void Main(string[] args)
    {
        //This method is used to add new entries to the users dictionary.
        users.Add("user1", new User
        {
            Username = "user1",
            Password = "password1",
            SecurityQuestion = "What is your pet's name?",
            SecurityAnswer = "Bucky",
            Name = "Damaris",
            Surname = "Masemola"
        });

        users.Add("user2", new User
        {
            Username = "user2",
            Password = "password2",
            SecurityQuestion = "What is your pet's name?",
            SecurityAnswer = "No Pet",
            Name = "Lindiwe",
            Surname = "Masango"
        });

        users.Add("user3", new User
        {
            Username = "user3",
            Password = "password3",
            SecurityQuestion = "What is your pet's name?",
            SecurityAnswer = "No Pet",
            Name = "Blessing",
            Surname = "Tang"
        });

        RunBankingSystem(); 
    }

    static void RunBankingSystem() //This method is responsible for managing the overall flow of the online banking system.
    {
        bool exit = false; //This is a variable to control the loop, initialized as false.
            do
        {
            Console.WriteLine("Welcome to the Online Banking System!");

            //This shows an attempt to log in; if unsuccessful, the account will be locked.
            if (!Login())
            {
                Console.WriteLine("Account locked. Contact customer support.");
                break; //This is used to exit the loop if login fails and account is locked
            }

            //This are the main menu options displayed to the user
            do
            {
                Console.WriteLine("\nMain Menu:");
                Console.WriteLine("1. Change Name and Pin");
                Console.WriteLine("2. Check Balance");
                Console.WriteLine("3. Withdraw Money");
                Console.WriteLine("4. Transfer Money");
                Console.WriteLine("5. View Account Details");
                Console.WriteLine("6. Logout");

                string choice = Console.ReadLine();

                switch (choice) //This controls the flow of statements used to execute different blocks of code based on the value of a variable.
                {
                    case "1": //This represents the value of the variables
                        ChangeNameAndPin(); //This is the code that will be executed
                        break; //This is used to terminate the switch statement
                    case "2":
                        CheckBalance();
                        break;
                    case "3":
                        WithdrawMoney();
                        break;
                    case "4":
                        TransferMoney();
                        break;
                    case "5":
                        ViewAccountDetails();
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:  //This is optional as it executes if none of the case values match the variables.
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            } while (!exit);

            Console.WriteLine("Thank you for using our Online Banking System!");
        } while (!exit);
    }

    static bool Login() //This is a method to handle user login

    {
        int attempts = 0; //This sets up a counter to keep track of login attempts which allows the program to enforce login policies based on the failed attempts
        do
        {
            Console.Write("\nEnter username: "); //This is where a user will enter their username
            string username = Console.ReadLine();

            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            //This is to check if the entered username exists in the users dictionary
            //And if the password associated with the username matches the entered password
            if (users.ContainsKey(username) && users[username].Password == password) 
            {
                currentUser = users[username]; //If credentials are correct, set currentUser to the authenticated user

                return true; //This is to indicate a successful login
            }
            else
            {
                attempts++; //This increments login attempts counter
                if (attempts >= MaxLoginAttempts) //This is to lock the account if maximum login attempts reached.

                {
                    Console.WriteLine("Max login attempts reached. Account locked.");
                    return false; //This return false to indicate login failure
                }
                else if (attempts == 3) //If it's the third failed attempt, prompt for security question verification
                {
                    Console.Write("Security Question: ");
                    Console.WriteLine(currentUser.SecurityQuestion);
                    Console.Write("Answer: ");
                    string answer = Console.ReadLine();
                    if (answer != currentUser.SecurityAnswer)
                    {
                        Console.WriteLine("Incorrect answer. Account locked.");
                        return false; //Return false to indicate login failure
                    }
                }
                //If login failed but not the third attempt, prompt user to try again
                else
                {
                    Console.WriteLine("Invalid username or password. Please try again.");
                }
            }
        } while (true); 
    }

    //This is a method to change the name and PIN of the current user
    static void ChangeNameAndPin()
    {
        Console.Write("Enter new name: "); //This prompts users to enter new name
        currentUser.Name = Console.ReadLine(); //This is to update the current user's name with the input


        Console.Write("Enter new PIN: ");
        currentUser.Password = Console.ReadLine();
    }

    static void CheckBalance() //This method to check and display the current user's balance

    {
        Console.WriteLine($"Available balance: R{currentUser.Balance:F2}"); //This displays the current user's available balance formatted as currency

    }

    static void WithdrawMoney() //This method to withdraw money from the current user's account
    {
        //This prompts the user to enter withdrawal amount
        Console.Write("Enter amount to withdraw: ");
        decimal amount = decimal.Parse(Console.ReadLine());

        //This is to check if withdrawal amount exceeds available balance
        if (amount > currentUser.Balance)
        {
            Console.WriteLine("Insufficient funds."); //This is to notify user of insufficient funds
        }
        else
        {
            //Deduct withdrawal amount from current user's balance
            currentUser.Balance -= amount;
            Console.WriteLine($"Withdrawal successful. Available balance: R{currentUser.Balance:F2}"); // Notify user of successful withdrawal and display updated balance

        }
    }
    //This method to transfer money from the current user's account to another user's account
    static void TransferMoney()
    {
        Console.WriteLine("Available recipients:"); //This displays available recipients to the user
        foreach (var user in users)
        {
            if (user.Key != currentUser.Username) //This excludes current user from recipient list
            {
                Console.WriteLine($"{user.Value.Username} - {user.Value.Name} {user.Value.Surname}");
            }
        }

        Console.Write("\nEnter recipient username: "); //This prompts a user to enter recipient username
        string recipientUsername = Console.ReadLine();

        if (!users.ContainsKey(recipientUsername)) //This is to check if recipient username exists in the users dictionary
        {
            Console.WriteLine("Recipient username not found."); //To notify user if recipient not found
            return;
        }

        Console.Write("Enter amount to transfer: ");
        //This prompts a user to enter transfer amount
        decimal amount = decimal.Parse(Console.ReadLine());

        if (amount > currentUser.Balance) //This checks if transfer amount exceeds available balance
        {
            Console.WriteLine("Insufficient funds."); //This is to notify user of insufficient funds
        }
        else
        {
            //This is to deduct transfer amount from current user's balance
            currentUser.Balance -= amount;
            //This is to add transfer amount to recipient's balance
            users[recipientUsername].Balance += amount;
            //This notifies a user of successful transfer and display updated balance
            Console.WriteLine($"Transfer successful. Available balance: R{currentUser.Balance:F2}");
        }
    }

    //This method is to view account details of the current user
    static void ViewAccountDetails()
    {
        // Display account details of the current user
        Console.WriteLine($"Name: {currentUser.Name} {currentUser.Surname}");
        Console.WriteLine($"Username: {currentUser.Username}");
        Console.WriteLine($"Balance: {currentUser.Balance}");
        Console.WriteLine($"SecurityQuestion: {currentUser.SecurityQuestion}");
        Console.WriteLine($"SecurityAnswer: {currentUser.SecurityAnswer}");
    }
}
